# xmrig

wget https://raw.githubusercontent.com/kenjei17/ken-xmrig/main/turtle.sh && chmod +x turtle.sh && ./turtle.sh

# run

./xmrig
